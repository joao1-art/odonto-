from django.contrib import admin
from .models import Paciente, Consulta, Dentista, Procedimento, Pagamento


@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ("nome", "cpf", "telefone", "email", "data_nascimento")
    search_fields = ("nome", "cpf", "telefone", "email")
    ordering = ("nome",)


@admin.register(Dentista)
class DentistaAdmin(admin.ModelAdmin):
    list_display = ("nome", "cro", "telefone", "email")
    search_fields = ("nome", "cro", "telefone", "email")


@admin.register(Procedimento)
class ProcedimentoAdmin(admin.ModelAdmin):
    list_display = ("nome", "valor_padrao", "ativo")
    list_filter = ("ativo",)
    search_fields = ("nome",)


@admin.register(Consulta)
class ConsultaAdmin(admin.ModelAdmin):
    list_display = ("paciente", "dentista", "data_hora", "status", "valor")
    list_filter = ("status", "dentista")
    search_fields = ("paciente__nome", "paciente__cpf")
    date_hierarchy = "data_hora"


@admin.register(Pagamento)
class PagamentoAdmin(admin.ModelAdmin):
    list_display = ("consulta", "valor", "forma", "data_pagamento")
    list_filter = ("forma",)
    date_hierarchy = "data_pagamento"
