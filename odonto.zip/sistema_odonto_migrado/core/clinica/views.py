from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import (
    ConsultaForm,
    DentistaForm,
    PacienteForm,
    PagamentoForm,
    ProcedimentoForm,
)
from .models import Consulta, Dentista, Paciente, Pagamento, Procedimento


def _paginate(request, queryset, per_page=10):
    paginator = Paginator(queryset, per_page)
    page_number = request.GET.get("page")
    return paginator.get_page(page_number)


@login_required
def dashboard(request):
    now = timezone.now()
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)

    total_pacientes = Paciente.objects.count()
    consultas_hoje = Consulta.objects.filter(data_hora__gte=start, data_hora__lt=end).count()
    proximas = (
        Consulta.objects.select_related("paciente", "dentista", "procedimento")
        .filter(data_hora__gte=now)
        .order_by("data_hora")[:8]
    )
    pagamentos_mes = (
        Pagamento.objects.filter(
            data_pagamento__year=now.year,
            data_pagamento__month=now.month,
        ).aggregate(total=Sum("valor"))
    )["total"] or 0

    return render(
        request,
        "dashboard.html",
        {
            "total_pacientes": total_pacientes,
            "consultas_hoje": consultas_hoje,
            "pagamentos_mes": pagamentos_mes,
            "proximas": proximas,
        },
    )


# -------- Pacientes --------
@login_required
def pacientes_list(request):
    q = request.GET.get("q", "").strip()
    qs = Paciente.objects.all().order_by("nome")
    if q:
        qs = qs.filter(Q(nome__icontains=q) | Q(cpf__icontains=q) | Q(telefone__icontains=q) | Q(email__icontains=q))
    page = _paginate(request, qs, per_page=12)
    return render(request, "pacientes/list.html", {"page": page, "q": q})


@login_required
def paciente_detail(request, pk):
    paciente = get_object_or_404(Paciente, pk=pk)
    consultas = (
        Consulta.objects.select_related("dentista", "procedimento")
        .filter(paciente=paciente)
        .order_by("-data_hora")
    )
    return render(request, "pacientes/detail.html", {"paciente": paciente, "consultas": consultas})


@login_required
def paciente_create(request):
    if request.method == "POST":
        form = PacienteForm(request.POST)
        if form.is_valid():
            paciente = form.save()
            messages.success(request, "Paciente cadastrado com sucesso.")
            return redirect("paciente_detail", pk=paciente.pk)
    else:
        form = PacienteForm()
    return render(request, "generic/form.html", {"title": "Novo paciente", "form": form, "cancel_url": "pacientes_list"})


@login_required
def paciente_update(request, pk):
    paciente = get_object_or_404(Paciente, pk=pk)
    if request.method == "POST":
        form = PacienteForm(request.POST, instance=paciente)
        if form.is_valid():
            form.save()
            messages.success(request, "Paciente atualizado.")
            return redirect("paciente_detail", pk=paciente.pk)
    else:
        form = PacienteForm(instance=paciente)
    return render(request, "generic/form.html", {"title": "Editar paciente", "form": form, "cancel_url": "paciente_detail", "cancel_kwargs": {"pk": paciente.pk}})


@login_required
def paciente_delete(request, pk):
    paciente = get_object_or_404(Paciente, pk=pk)
    if request.method == "POST":
        paciente.delete()
        messages.success(request, "Paciente removido.")
        return redirect("pacientes_list")
    return render(request, "generic/confirm_delete.html", {"title": "Excluir paciente", "object": paciente, "cancel_url": "paciente_detail", "cancel_kwargs": {"pk": paciente.pk}})


# -------- Dentistas --------
@login_required
def dentistas_list(request):
    q = request.GET.get("q", "").strip()
    qs = Dentista.objects.all().order_by("nome")
    if q:
        qs = qs.filter(Q(nome__icontains=q) | Q(cro__icontains=q) | Q(telefone__icontains=q) | Q(email__icontains=q))
    page = _paginate(request, qs, per_page=12)
    return render(request, "dentistas/list.html", {"page": page, "q": q})


@login_required
def dentista_create(request):
    if request.method == "POST":
        form = DentistaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Dentista cadastrado.")
            return redirect("dentistas_list")
    else:
        form = DentistaForm()
    return render(request, "generic/form.html", {"title": "Novo dentista", "form": form, "cancel_url": "dentistas_list"})


@login_required
def dentista_update(request, pk):
    dentista = get_object_or_404(Dentista, pk=pk)
    if request.method == "POST":
        form = DentistaForm(request.POST, instance=dentista)
        if form.is_valid():
            form.save()
            messages.success(request, "Dentista atualizado.")
            return redirect("dentistas_list")
    else:
        form = DentistaForm(instance=dentista)
    return render(request, "generic/form.html", {"title": "Editar dentista", "form": form, "cancel_url": "dentistas_list"})


@login_required
def dentista_delete(request, pk):
    dentista = get_object_or_404(Dentista, pk=pk)
    if request.method == "POST":
        dentista.delete()
        messages.success(request, "Dentista removido.")
        return redirect("dentistas_list")
    return render(request, "generic/confirm_delete.html", {"title": "Excluir dentista", "object": dentista, "cancel_url": "dentistas_list"})


# -------- Procedimentos --------
@login_required
def procedimentos_list(request):
    q = request.GET.get("q", "").strip()
    qs = Procedimento.objects.all().order_by("nome")
    if q:
        qs = qs.filter(Q(nome__icontains=q))
    page = _paginate(request, qs, per_page=12)
    return render(request, "procedimentos/list.html", {"page": page, "q": q})


@login_required
def procedimento_create(request):
    if request.method == "POST":
        form = ProcedimentoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Procedimento cadastrado.")
            return redirect("procedimentos_list")
    else:
        form = ProcedimentoForm()
    return render(request, "generic/form.html", {"title": "Novo procedimento", "form": form, "cancel_url": "procedimentos_list"})


@login_required
def procedimento_update(request, pk):
    proc = get_object_or_404(Procedimento, pk=pk)
    if request.method == "POST":
        form = ProcedimentoForm(request.POST, instance=proc)
        if form.is_valid():
            form.save()
            messages.success(request, "Procedimento atualizado.")
            return redirect("procedimentos_list")
    else:
        form = ProcedimentoForm(instance=proc)
    return render(request, "generic/form.html", {"title": "Editar procedimento", "form": form, "cancel_url": "procedimentos_list"})


@login_required
def procedimento_delete(request, pk):
    proc = get_object_or_404(Procedimento, pk=pk)
    if request.method == "POST":
        proc.delete()
        messages.success(request, "Procedimento removido.")
        return redirect("procedimentos_list")
    return render(request, "generic/confirm_delete.html", {"title": "Excluir procedimento", "object": proc, "cancel_url": "procedimentos_list"})


# -------- Consultas --------
@login_required
def consultas_list(request):
    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "").strip()

    qs = Consulta.objects.select_related("paciente", "dentista", "procedimento").order_by("-data_hora")

    if q:
        qs = qs.filter(
            Q(paciente__nome__icontains=q)
            | Q(paciente__cpf__icontains=q)
            | Q(dentista__nome__icontains=q)
            | Q(procedimento__nome__icontains=q)
            | Q(procedimento_desc__icontains=q)
        )

    if status:
        qs = qs.filter(status=status)

    page = _paginate(request, qs, per_page=12)
    return render(request, "consultas/list.html", {"page": page, "q": q, "status": status})


@login_required
def consulta_detail(request, pk):
    consulta = get_object_or_404(Consulta.objects.select_related("paciente", "dentista", "procedimento"), pk=pk)
    pagamentos = consulta.pagamentos.order_by("-data_pagamento")
    total_pago = pagamentos.aggregate(total=Sum("valor"))["total"] or 0
    saldo = consulta.valor - total_pago
    return render(request, "consultas/detail.html", {"consulta": consulta, "pagamentos": pagamentos, "total_pago": total_pago, "saldo": saldo})


@login_required
def consulta_create(request):
    if request.method == "POST":
        form = ConsultaForm(request.POST)
        if form.is_valid():
            consulta = form.save()
            messages.success(request, "Consulta registrada.")
            return redirect("consulta_detail", pk=consulta.pk)
    else:
        form = ConsultaForm()
    return render(request, "generic/form.html", {"title": "Nova consulta", "form": form, "cancel_url": "consultas_list"})


@login_required
def consulta_update(request, pk):
    consulta = get_object_or_404(Consulta, pk=pk)
    if request.method == "POST":
        form = ConsultaForm(request.POST, instance=consulta)
        if form.is_valid():
            form.save()
            messages.success(request, "Consulta atualizada.")
            return redirect("consulta_detail", pk=consulta.pk)
    else:
        form = ConsultaForm(instance=consulta)
    return render(request, "generic/form.html", {"title": "Editar consulta", "form": form, "cancel_url": "consulta_detail", "cancel_kwargs": {"pk": consulta.pk}})


@login_required
def consulta_delete(request, pk):
    consulta = get_object_or_404(Consulta, pk=pk)
    if request.method == "POST":
        consulta.delete()
        messages.success(request, "Consulta removida.")
        return redirect("consultas_list")
    return render(request, "generic/confirm_delete.html", {"title": "Excluir consulta", "object": consulta, "cancel_url": "consulta_detail", "cancel_kwargs": {"pk": consulta.pk}})


# -------- Pagamentos --------
@login_required
def pagamentos_list(request):
    q = request.GET.get("q", "").strip()
    qs = Pagamento.objects.select_related("consulta", "consulta__paciente").order_by("-data_pagamento")
    if q:
        qs = qs.filter(Q(consulta__paciente__nome__icontains=q) | Q(consulta__paciente__cpf__icontains=q))
    page = _paginate(request, qs, per_page=12)
    total = qs.aggregate(total=Sum("valor"))["total"] or 0
    return render(request, "pagamentos/list.html", {"page": page, "q": q, "total": total})


@login_required
def pagamento_create(request, consulta_pk=None):
    initial = {}
    if consulta_pk:
        initial["consulta"] = consulta_pk

    if request.method == "POST":
        form = PagamentoForm(request.POST)
        if form.is_valid():
            pag = form.save()
            messages.success(request, "Pagamento lançado.")
            return redirect("consulta_detail", pk=pag.consulta.pk)
    else:
        form = PagamentoForm(initial=initial)

    return render(request, "generic/form.html", {"title": "Novo pagamento", "form": form, "cancel_url": "pagamentos_list"})


@login_required
def pagamento_delete(request, pk):
    pag = get_object_or_404(Pagamento, pk=pk)
    consulta_pk = pag.consulta.pk
    if request.method == "POST":
        pag.delete()
        messages.success(request, "Pagamento removido.")
        return redirect("consulta_detail", pk=consulta_pk)
    return render(request, "generic/confirm_delete.html", {"title": "Excluir pagamento", "object": pag, "cancel_url": "consulta_detail", "cancel_kwargs": {"pk": consulta_pk}})
