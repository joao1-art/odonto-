from django import forms
from .models import Paciente, Consulta, Dentista, Procedimento, Pagamento


class DateInput(forms.DateInput):
    input_type = "date"


class DateTimeInput(forms.DateTimeInput):
    input_type = "datetime-local"


class PacienteForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = ["nome", "cpf", "telefone", "email", "data_nascimento"]
        widgets = {"data_nascimento": DateInput()}


class DentistaForm(forms.ModelForm):
    class Meta:
        model = Dentista
        fields = ["nome", "cro", "telefone", "email"]


class ProcedimentoForm(forms.ModelForm):
    class Meta:
        model = Procedimento
        fields = ["nome", "valor_padrao", "ativo"]


class ConsultaForm(forms.ModelForm):
    class Meta:
        model = Consulta
        fields = [
            "paciente",
            "dentista",
            "data_hora",
            "duracao_min",
            "procedimento",
            "procedimento_desc",
            "status",
            "valor",
            "observacoes",
        ]
        widgets = {
            "data_hora": DateTimeInput(),
            "procedimento_desc": forms.Textarea(attrs={"rows": 2}),
            "observacoes": forms.Textarea(attrs={"rows": 3}),
        }


class PagamentoForm(forms.ModelForm):
    class Meta:
        model = Pagamento
        fields = ["consulta", "data_pagamento", "valor", "forma", "observacoes"]
        widgets = {
            "data_pagamento": DateTimeInput(),
        }
