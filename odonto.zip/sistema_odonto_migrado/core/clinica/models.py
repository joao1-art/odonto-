from django.db import models
from django.utils import timezone


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Dentista(TimeStampedModel):
    nome = models.CharField(max_length=120)
    cro = models.CharField("CRO", max_length=30, blank=True)
    telefone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)

    def __str__(self):
        return self.nome


class Paciente(TimeStampedModel):
    nome = models.CharField(max_length=100)
    cpf = models.CharField(max_length=14, unique=True)
    telefone = models.CharField(max_length=15)
    email = models.EmailField(blank=True)
    data_nascimento = models.DateField()

    def __str__(self):
        return self.nome


class Procedimento(TimeStampedModel):
    nome = models.CharField(max_length=120)
    valor_padrao = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    ativo = models.BooleanField(default=True)

    def __str__(self):
        return self.nome


class ConsultaStatus(models.TextChoices):
    AGENDADA = "AGENDADA", "Agendada"
    REALIZADA = "REALIZADA", "Realizada"
    CANCELADA = "CANCELADA", "Cancelada"


class Consulta(TimeStampedModel):
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE)
    dentista = models.ForeignKey(Dentista, on_delete=models.PROTECT, null=True, blank=True)
    data_hora = models.DateTimeField(default=timezone.now)
    duracao_min = models.PositiveIntegerField(default=30)
    procedimento = models.ForeignKey(Procedimento, on_delete=models.PROTECT, null=True, blank=True)
    procedimento_desc = models.TextField("Descrição (opcional)", blank=True)
    status = models.CharField(max_length=20, choices=ConsultaStatus.choices, default=ConsultaStatus.AGENDADA)
    valor = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    observacoes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.paciente.nome} - {self.data_hora:%d/%m/%Y %H:%M}"


class FormaPagamento(models.TextChoices):
    DINHEIRO = "DINHEIRO", "Dinheiro"
    PIX = "PIX", "PIX"
    CARTAO = "CARTAO", "Cartão"
    TRANSFERENCIA = "TRANSFERENCIA", "Transferência"


class Pagamento(TimeStampedModel):
    consulta = models.ForeignKey(Consulta, on_delete=models.CASCADE, related_name="pagamentos")
    data_pagamento = models.DateTimeField(default=timezone.now)
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    forma = models.CharField(max_length=20, choices=FormaPagamento.choices, default=FormaPagamento.PIX)
    observacoes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Pagamento {self.valor} ({self.forma})"
