from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),

    path("pacientes/", views.pacientes_list, name="pacientes_list"),
    path("pacientes/novo/", views.paciente_create, name="paciente_create"),
    path("pacientes/<int:pk>/", views.paciente_detail, name="paciente_detail"),
    path("pacientes/<int:pk>/editar/", views.paciente_update, name="paciente_update"),
    path("pacientes/<int:pk>/excluir/", views.paciente_delete, name="paciente_delete"),

    path("dentistas/", views.dentistas_list, name="dentistas_list"),
    path("dentistas/novo/", views.dentista_create, name="dentista_create"),
    path("dentistas/<int:pk>/editar/", views.dentista_update, name="dentista_update"),
    path("dentistas/<int:pk>/excluir/", views.dentista_delete, name="dentista_delete"),

    path("procedimentos/", views.procedimentos_list, name="procedimentos_list"),
    path("procedimentos/novo/", views.procedimento_create, name="procedimento_create"),
    path("procedimentos/<int:pk>/editar/", views.procedimento_update, name="procedimento_update"),
    path("procedimentos/<int:pk>/excluir/", views.procedimento_delete, name="procedimento_delete"),

    path("consultas/", views.consultas_list, name="consultas_list"),
    path("consultas/nova/", views.consulta_create, name="consulta_create"),
    path("consultas/<int:pk>/", views.consulta_detail, name="consulta_detail"),
    path("consultas/<int:pk>/editar/", views.consulta_update, name="consulta_update"),
    path("consultas/<int:pk>/excluir/", views.consulta_delete, name="consulta_delete"),

    path("pagamentos/", views.pagamentos_list, name="pagamentos_list"),
    path("pagamentos/novo/", views.pagamento_create, name="pagamento_create"),
    path("consultas/<int:consulta_pk>/pagamentos/novo/", views.pagamento_create, name="pagamento_create_for_consulta"),
    path("pagamentos/<int:pk>/excluir/", views.pagamento_delete, name="pagamento_delete"),
]
